# RDP Wrapper Library by Stas'M mod by sebaxakerhtc

### All thanks for the project to [Stas'M](https://github.com/stascorp/rdpwrap)

### Building the binaries:
- **x86 Delphi version** can be built with *Embarcadero RAD Studio 11*

### Manual on and off H264 priority:
- Download [LGPO](https://www.microsoft.com/en-us/download/details.aspx?id=55319)
- Use files H264_ON and H264_OFF

### Binary files content:
Installer and uninstaller assembled and can be disassembled using freeware [Bat to Exe Converter](https://web.archive.org/web/20190305143024/http://f2ko.de/en/b2e.php)

### Installation:
- Disable your antivirus software
- Run Installer or Installer Black
- Add exclusion for "C:\Program Files\RDP Wrapper" folder
- Enable your antivirus software
- Enjoy!
